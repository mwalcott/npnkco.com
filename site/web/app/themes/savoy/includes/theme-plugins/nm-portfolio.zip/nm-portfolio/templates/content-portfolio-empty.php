<p class="nm-portfolio-empty"><?php esc_html_e( 'No items added yet.', 'nm-portfolio' ); ?></p>
