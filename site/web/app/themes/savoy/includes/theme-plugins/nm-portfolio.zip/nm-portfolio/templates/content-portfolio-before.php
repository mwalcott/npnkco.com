<?php
global $nm_portfolio_options;

// Packery
if ( $nm_portfolio_options['packery'] ) {
    // Enqueue "Packery" script
    wp_enqueue_script( 'packery', NM_THEME_URI . '/js/plugins/packery.pkgd.min.js', array(), '1.3.2', true );
    
    $wrapper_class = ' packery-enabled';
    $loader_class = ' nm-loader';
} else {
    $wrapper_class = $loader_class = '';
}

// Filters menu
if ( $nm_portfolio_options['filters'] ) {
    $args = array(
        'type'			=> 'post',
        'orderby'		=> 'name',
        'order'			=> 'ASC',
        'hide_empty'	=> 0,
        'hierarchical'	=> 1,
        'taxonomy'		=> 'portfolio-category'
    );
    $categories = get_categories( $args );
    $filters_menu = '';

    foreach ( $categories as $category ) {
        $filters_menu .= '<li><span>&frasl;</span><a href="#" data-filter="' . esc_attr( $category->slug ) . '">' . esc_html( $category->name ) . '</a></li>';
    }
    $filters_menu = '<ul class="nm-portfolio-filters align-' . esc_attr( $nm_portfolio_options['filters_alignment'] ) . '"><li class="current"><a href="#">' . __( 'All', 'nm-portfolio' ) . '</a></li>' . $filters_menu . '</ul>';
} else {
    $wrapper_class .= ' no-filters';
    $filters_menu = '';
}
?>

<?php do_action( 'nm_portfolio_before' ); ?>

<div class="nm-portfolio layout-<?php echo esc_attr( $nm_portfolio_options['layout'] ) . $wrapper_class; ?>">
    <?php echo $filters_menu; ?>

    <ul class="nm-portfolio-grid small-block-grid-1 medium-block-grid-2 large-block-grid-<?php echo intval( $nm_portfolio_options['columns'] ) . $loader_class; ?>">